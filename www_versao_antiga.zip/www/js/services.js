angular.module('starter.services', [])


.service('LoginService', function($q) {
    return {
        loginUser: function(name, pw) {
            var deferred = $q.defer();
            var promise = deferred.promise;

            if (name == 'user' && pw == 'secret') {
                deferred.resolve('Welcome ' + name + '!');
            } else {
                deferred.reject('Wrong credentials.');
            }
            promise.success = function(fn) {
                promise.then(fn);
                return promise;
            }
            promise.error = function(fn) {
                promise.then(null, fn);
                return promise;
            }
            return promise;
        }
    }
})

.service('SignupService',function($q) {
	return {
		signupUser: function (name, pass) {
			var deferred = $q.defer();
			var promise = deferred.promise;

			if (name != 'user') {
                deferred.resolve('Account Created');
			} else {
                deferred.reject('Account already exists');
			}
			promise.success = function(fn) {
				promise.then(fn);
				return promise;
			}
			promise.error = function(fn) {
				promise.then(null,fn);
				return promise;
			}
			return promise;
		}

	}
})

.factory('sugestao', function(){
    var oasd = [{
        nome: "metodologia de desenvolvimento de software - A",
        horario: "08-10",
        dia: "segunda e quarta"
    }, {
        nome: "",
        horario: "08-10",
        dia: "terça"
    }, {
        nome: "metodologia de desenvolvimento de software - A",
        horario: "08-10",
        dia: "segunda e quarta"
    }, {
        nome: "",
        horario: "08-10",
        dia: "quinta"
    }, {
        nome: "",
        horario: "08-10",
        dia: "sexta"
    }, {
        nome: "",
        horario: "08-10",
        dia: "sabado"
    }];

    return {
        gera: function() {
            return oasd;
        }
    };
});
