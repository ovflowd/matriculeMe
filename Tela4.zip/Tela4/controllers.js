angular.module('starter.controllers', [])

.controller("mostrar",function($scope,$http,$ionicModal){
    $http.get('sugestoes.json')
        .success(function (data){
            $scope.sugestoes=data.sugestoes;
            $scope.sugestoes.sort();
        });
        
    $ionicModal.fromTemplateUrl('pop-up-motivo.html', function(modal) {
        $scope.taskModal = modal;
      }, {
        scope: $scope
      });
      
    $scope.mostraMotivo = function(sugestao,index) {
        //não encontrei foma mais simples de fazer isso funcionar. Variáveis somente são apresentadas se forem parte de $scope, então criei esta swap que pode ajudar em vários contextos parecidos
        $scope.swap=sugestao;
        $scope.taskModal.show();
    };

    $scope.closePopUp = function() {
        $scope.taskModal.hide();
    }
      
});
