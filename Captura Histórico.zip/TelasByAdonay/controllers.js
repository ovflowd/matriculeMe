angular.module('starter.controllers', [])

.controller('WebCtrl', function($scope, $stateParams, $timeout) {
    //Este controler deve ser reiniciado sempre que a tela for acessada.
    $scope.saida="vazio";
    var timer=null;
    //Ocultar o frame durante a navegação
    var x = document.getElementById("oi");
    x.style.display='none';
    //Abrir a página de login
    var frame=window.frames[0];
    frame.location="http://wwwsec.serverweb.unb.br/graduacao/sec/login.aspx";
    
    //Função que automatiza a captura e navegação
    verifica=function(){
        //Obtem o conteúdo (document) do iframe
        var x = document.getElementById("oi");
        x.style.display='none';
        var y = (x.contentWindow || x.contentDocument);
        if (y.document) y = y.document; //Access denied! (no browser, via emulador rola de boa)
        //Verifica se está na página de login
        var qtd=y.getElementsByName("inputMatricula").length;
        //Se estiver na página de login, não faz nada
        if (!qtd){
            //Se não for a página de login, verifica se o histórico está aberto
            if (y.getElementById("alumatricula") != null){
                //Se for o histórico, captura e envia, muda de estado
                //Verificar se o envio do HTML via $http funciona
                //$http.post(y.body.innerHTML);
                //por alguma razão o echo somente acontece ao clicar no botão que não tem função associada o.O 
                $scope.saida=y.body.innerHTML;//echo
                //O alert abaixo funciona, logo esta parte da função é executada em algum momento
                alert("Seu histórico foi atualizado em nossa base de dados");
                clearInterval(timer);
                //$state.go(#/tela4);
            }else{
                //Se não for a página do histórico, verifica se o aluno está logado
                qtd=y.getElementsByClassName("PadraoMenu").length;
                if (qtd>1){
                    //Se estiver logado, abre a página do histórico
                    frame.location="https://wwwsec.serverweb.unb.br/graduacao/sec/he.aspx";
                }else{
                    //Se não estiver logado, direciona para a página de login
                    frame.location="http://wwwsec.serverweb.unb.br/graduacao/sec/login.aspx";
                    x.style.display='block';
                }
            }
        }
    };
    
    //Faz verificações a cada ~3 segundos. O ideal seria usar "onload" ou "document.ready" mas não estavam se comportando como esperado
    timer=setInterval(verifica,3000);
})

});
    
    
